import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { userProfile as defaultUser } from '../data/mockData'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('user')
      return saved ? JSON.parse(saved) : null
    } catch {
      return null
    }
  })

  useEffect(() => {
    if (user) localStorage.setItem('user', JSON.stringify(user))
    else localStorage.removeItem('user')
  }, [user])

  const login = useCallback((email) => {
    const u = { ...defaultUser, email }
    setUser(u)
    return u
  }, [])

  const register = useCallback((data) => {
    const u = { firstName: data.firstName, lastName: data.lastName, email: data.email, phone: data.phone }
    setUser(u)
    return u
  }, [])

  const logout = useCallback(() => setUser(null), [])

  const updateProfile = useCallback((data) => {
    setUser(prev => prev ? { ...prev, ...data } : prev)
  }, [])

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateProfile, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
